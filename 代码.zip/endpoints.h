#pragma once
#ifndef ENDPOINTS_H
#define ENDPOINTS_H

#include <opencv2\opencv.hpp>
#include <vector>
#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <stdlib.h>
#include <algorithm>
using namespace std;
using namespace cv;
namespace pgcv {
	void endpoints(cv::Mat img, std::vector<cv::Point>& endP);
}

#endif