#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <vector>
#include <stdlib.h>
#include <algorithm>
#include <iostream>
#include<opencv2\core\core.hpp>  
#include "thinning.h"
#include "endpoints.h"
#include "DijkstraShortPath.h"
using namespace cv;
using namespace std;
using namespace pgcv;
int main() {
	cv::Mat im0 = cv::imread("2.jpg", 0); //��ȡͼƬ
	cv::resize(im0, im0, cv::Size(1280, 720), 0, 0, INTER_LINEAR); //��ͼƬ��������1280X720
	cv::Mat bw;
	cv::threshold(im0, bw, 127, 255,THRESH_BINARY); //��ֵ��
	thinning(bw, bw); //�����Թ��߿�����
	cv::imshow("Mazethinning", bw);
	cv::waitKey(0);
	//����߽�
	for (int r = 0; r < bw.rows; r++) {
		cv::Point P;
		P.x = 0;
		P.y = r;
		bw.at<uchar>(P) = 0;
		P.x = bw.cols-1;
		P.y = r;
		bw.at<uchar>(P) = 0;
	}
	for (int c = 0; c < bw.cols; c++) {
		cv::Point P;
		P.x = c;
		P.y = 0;
		bw.at<uchar>(P) = 0;
		P.x = c;
		P.y = bw.rows-1;
		bw.at<uchar>(P) = 0;
	}
	cv::imshow("Maze", bw);
	cv::waitKey(0);

	std::vector<cv::Point> endP;
	endpoints(bw, endP);

	//�ҵ������յ�
	cv::Point startPxl;
	cv::Point endPxl;

	int I_find_first_one = 0; 
	for (int i = 0; i < endP.size(); i++) { 
		cv::Point P = endP[i];
		/*std::cout << P << std::endl;*/
		if (P.x == 1 || P.y == 1 || P.x==bw.cols-2 || P.y==bw.rows-2) { 
			if (!I_find_first_one) {
				startPxl = P;
				I_find_first_one = 1; //�ҵ����
			}
			else
				endPxl = P;
		}
	}


	std::vector<cv::Point> Result;
	DijkstraShortPath(bw , startPxl , endPxl , Result); //�Ͻ�˹�����㷨���Թ�


	////����Ƶչʾ
	std::cout << "HI" << std::endl << "Let's Solve the Maze!" << std::endl <<std::endl;
	cv::Mat im;
	std::vector<cv::Mat> im2(3);
	im2[0] = im0;
	im2[1] = im0;
	im2[2] = im0;
	cv::merge(im2, im);
	//VideoWriter video("F:\\test.avi", VideoWriter::fourcc('X', 'V', 'I', 'D'), 24.0, Size(1280, 720));
	for (int n = 0; n < Result.size(); n++) {
		im.at<cv::Vec3b>(Result[n])[0] = 0;
		im.at<cv::Vec3b>(Result[n])[1] = 0;
		//	video << im;
		cv::namedWindow("MazeSolver");
		cv::imshow("MazeSolver", im);
		cv::waitKey(1);
	}
	cv::waitKey(0);
}