#include "DijkstraShortPath.h"

typedef int vertex_t;
typedef double weight_t;

const weight_t max_weight = std::numeric_limits<double>::infinity();

struct neighbor {
	vertex_t target;
	weight_t weight;
	neighbor(vertex_t arg_target, weight_t arg_weight)
		: target(arg_target), weight(arg_weight) { }
};

typedef std::vector<std::vector<neighbor> > adjacency_list_t;


void DijkstraComputePaths(vertex_t source,
	const adjacency_list_t &adjacency_list,
	std::vector<weight_t> &min_distance,
	std::vector<vertex_t> &previous)
{
	int n = adjacency_list.size();
	min_distance.clear();
	min_distance.resize(n, max_weight);
	min_distance[source] = 0;
	previous.clear();
	previous.resize(n, -1);
	std::set<std::pair<weight_t, vertex_t> > vertex_queue;
	vertex_queue.insert(std::make_pair(min_distance[source], source));

	while (!vertex_queue.empty())
	{
		weight_t dist = vertex_queue.begin()->first;
		vertex_t u = vertex_queue.begin()->second;
		vertex_queue.erase(vertex_queue.begin());

		const std::vector<neighbor> &neighbors = adjacency_list[u];
		for (std::vector<neighbor>::const_iterator neighbor_iter = neighbors.begin();
		neighbor_iter != neighbors.end();
			neighbor_iter++)
		{
			vertex_t v = neighbor_iter->target;
			weight_t weight = neighbor_iter->weight;
			weight_t distance_through_u = dist + weight;
			if (distance_through_u < min_distance[v]) {
				vertex_queue.erase(std::make_pair(min_distance[v], v));

				min_distance[v] = distance_through_u;
				previous[v] = u;
				vertex_queue.insert(std::make_pair(min_distance[v], v));

			}

		}
	}
}


std::vector<vertex_t> DijkstraGetShortestPathTo(
	vertex_t vertex, const std::vector<vertex_t> &previous)
{
	std::vector<vertex_t> path;
	for (; vertex != -1; vertex = previous[vertex])
		path.push_back(vertex);
	std::reverse(path.begin(), path.end());
	return path;
}

namespace pgcv {
	void DijkstraShortPath(cv::Mat InputBWImage , cv::Point Start , cv::Point End , std::vector<cv::Point>& Result)
	{

		cv::Mat bw = InputBWImage;
		if (bw.at<uchar>(Start) != 255 || bw.at<uchar>(End) != 255) { //如果起点或终点不合适，则错误
			std::cerr << "错误：起点或终点不在路径上" << std::endl;
			std::getchar();
			std::exit(0);
		}

		// 提取白色像素点作为图节点
		std::vector<cv::Point> nodes;
		cv::findNonZero(bw, nodes);

		// 将向量中每个白色像素点的索引保存在其他图像的相应像素上
		cv::Mat Index_of_nodes = cv::Mat::zeros(bw.size(), CV_32S); //相应像素中每个节点的平均索引
		for (int pidx = 0; pidx < nodes.size(); pidx++) {
			Index_of_nodes.at<int>(nodes[pidx]) = pidx;
		}

		//检查每个节点的邻域并保存找到边
		adjacency_list_t adjacency_list(nodes.size());

		for (int n = 0; n < nodes.size(); n++) {
			cv::Point node = nodes[n];

			for (int Nx = -1; Nx < 2; Nx++) {
				for (int Ny = -1; Ny < 2; Ny++) {
					if (Ny != 0 || Nx != 0) { //不检查节点本身

						//define the neighbor pixel
						cv::Point neighborP;
						neighborP.x = node.x + Nx;
						neighborP.y = node.y + Ny;

						cv::Rect rect(cv::Point(), bw.size());
						if (rect.contains(neighborP)) { //如果该点在图像内

							if (bw.at<uchar>(neighborP) == 255) { //如果邻节点为真
								int index = Index_of_nodes.at<int>(neighborP); //返回此像素的节点名称
								adjacency_list[n].push_back(neighbor(index, 1)); //在列表中写入节点的名称
							}
						}
					}
				}
			}
		}


		// 定义节点的起点和终点
		int StartNode = Index_of_nodes.at<int>(Start);
		int EndNode = Index_of_nodes.at<int>(End);


		// 做Dijkstra最短路径算法
		std::vector<weight_t> min_distance;
		std::vector<vertex_t> previous;
		DijkstraComputePaths(StartNode, adjacency_list, min_distance, previous);
		std::vector<vertex_t> path = DijkstraGetShortestPathTo(EndNode, previous);

		// 从“路径”节点重建图像像素
		for (int pn = 0; pn < path.size(); pn++) { //对于路径列表的每个元素
			int pnt = path[pn]; //路径中的节点号
			cv::Point pixel = nodes[pnt]; //节点对应的像素
			Result.push_back(pixel);

		}
	}
}
